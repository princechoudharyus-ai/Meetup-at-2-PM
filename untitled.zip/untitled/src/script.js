<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>4th July Countdown</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display",sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:
    radial-gradient(circle at top,#14213d 0%,#050505 70%);
    overflow:hidden;
    color:white;
}

.card{
    width:min(1000px,95%);
    padding:50px;
    border-radius:40px;
    background:rgba(255,255,255,.06);
    backdrop-filter:blur(40px);
    border:1px solid rgba(255,255,255,.1);
    box-shadow:
    0 20px 80px rgba(0,0,0,.5),
    inset 0 1px 0 rgba(255,255,255,.15);
}

.title{
    text-align:center;
    font-size:18px;
    letter-spacing:8px;
    opacity:.7;
}

.event{
    text-align:center;
    margin-top:20px;
    font-size:72px;
    font-weight:700;
    background:linear-gradient(90deg,#4da3ff,#ffffff,#ff6b6b);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.time{
    text-align:center;
    font-size:34px;
    margin-top:10px;
    opacity:.8;
}

.timer{
    margin-top:50px;
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:20px;
}

.unit{
    text-align:center;
}

.number{
    font-size:clamp(60px,9vw,130px);
    font-weight:300;
    line-height:1;
}

.label{
    margin-top:12px;
    font-size:14px;
    letter-spacing:4px;
    opacity:.6;
}

.line{
    height:4px;
    border-radius:999px;
    margin-top:40px;
    background:linear-gradient(90deg,#4da3ff,#ffffff,#ff6b6b);
    box-shadow:0 0 20px rgba(255,255,255,.5);
}

.footer{
    text-align:center;
    margin-top:20px;
    opacity:.5;
}

@media(max-width:700px){
    .timer{
        grid-template-columns:repeat(2,1fr);
    }

    .event{
        font-size:42px;
    }
}
</style>
</head>

<body>

<div class="card">

    <div class="title">COUNTDOWN TO</div>

    <div class="event">4TH JULY</div>

    <div class="time">2:00 PM</div>

    <div class="timer">

        <div class="unit">
            <div id="days" class="number">00</div>
            <div class="label">DAYS</div>
        </div>

        <div class="unit">
            <div id="hours" class="number">00</div>
            <div class="label">HOURS</div>
        </div>

        <div class="unit">
            <div id="minutes" class="number">00</div>
            <div class="label">MINUTES</div>
        </div>

        <div class="unit">
            <div id="seconds" class="number">00</div>
            <div class="label">SECONDS</div>
        </div>

    </div>

    <div class="line"></div>

    <div class="footer" id="dateText"></div>

</div>

<script>

const target = new Date("July 4, 2026 14:00:00").getTime();

document.getElementById("dateText").textContent =
"Friday, July 4 • 2:00 PM";

function update(){

    const now = new Date().getTime();
    const diff = target - now;

    if(diff <= 0){
        document.body.innerHTML =
        "<h1 style='font-family:-apple-system;color:white'>🎆 HAPPY 4TH OF JULY! 🎆</h1>";
        return;
    }

    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);

    daysEl.textContent = String(days).padStart(2,"0");
    hoursEl.textContent = String(hours).padStart(2,"0");
    minutesEl.textContent = String(minutes).padStart(2,"0");
    secondsEl.textContent = String(seconds).padStart(2,"0");
}

const daysEl = document.getElementById("days");
const hoursEl = document.getElementById("hours");
const minutesEl = document.getElementById("minutes");
const secondsEl = document.getElementById("seconds");

update();
setInterval(update,1000);

</script>

</body>
</html>